sarah_note1 = 10
sarah_note2 = 15
sarah_note3 = 11
sarah_note4 = 12
sarah_note5 = 18
sarah_note6 = 5
sarah_note7 = 20
